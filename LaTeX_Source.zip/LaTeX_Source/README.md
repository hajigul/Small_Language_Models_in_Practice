# Small Language Models in Practice — LaTeX Source

LaTeX source for the book by **Haji Gul**. Compiles with a standard pdfLaTeX
install (TeX Live / MiKTeX) — no shell-escape, no minted, no external tools.

## Files
- `main.tex` — entry point: custom TikZ title page + `\input` of each chapter
- `slmstyle.sty` — shared style: colors, code boxes, callouts, section design
- `chapters/00_preface.tex` … `chapters/08_capstone.tex` — the eight chapters + preface
- `make_notes.py` — script that generated the Jupyter lecture notes from these chapters

## Build
```bash
pdflatex main.tex
pdflatex main.tex      # run twice so the table of contents resolves
```
Output: `main.pdf`. A pre-built copy is included as
`Small_Language_Models_in_Practice_Haji_Gul.pdf`.

## Notes
- Uses `listings` + `tcolorbox` for syntax-highlighted code boxes, so it compiles
  anywhere without `--shell-escape`.
- The title page is drawn with TikZ; edit the author/title nodes in `main.tex`.
- A harmless "Illegal parameter number" warning from the listings/tcolorbox
  interaction may appear during page breaks; it does not affect the output.
- If your TeX install lacks `lmodern` or `inconsolata`, the style falls back to
  default fonts automatically.
