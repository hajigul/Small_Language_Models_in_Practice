import re, os, json, glob

CH_TITLES = {
 "01_intro":"Why Small Language Models",
 "02_setup_first_model":"Running Models Locally",
 "03_finetuning":"Fine-Tuning with LoRA",
 "04_rag":"Retrieval-Augmented Generation",
 "05_agents":"Agents and Tool Use",
 "06_quantization":"Quantization for Small Hardware",
 "07_deployment":"Serving and Deployment",
 "08_capstone":"Capstone: A Local Document Assistant",
}
ORDER = list(CH_TITLES.keys())
NUM = {k:i+1 for i,k in enumerate(ORDER)}

OUT = "/home/claude/SLM_Practice_LectureNotes"
os.makedirs(OUT, exist_ok=True)

def latex_to_text(s):
    # strip common latex inline markup for note cells
    s = s.replace("---","\u2014").replace("--","\u2013")
    s = re.sub(r"\\textbf\{([^}]*)\}", r"**\1**", s)
    s = re.sub(r"\\emph\{([^}]*)\}", r"*\1*", s)
    s = re.sub(r"\\textit\{([^}]*)\}", r"*\1*", s)
    s = re.sub(r"\\inlinecode\{([^}]*)\}", r"`\1`", s)
    s = re.sub(r"\\texttt\{([^}]*)\}", r"`\1`", s)
    s = re.sub(r"\\enquote\{([^}]*)\}", r'"\1"', s)
    s = re.sub(r"\\(section|subsection)\*?\{([^}]*)\}", r"## \2", s)
    s = re.sub(r"\\item\s*", r"- ", s)
    s = re.sub(r"\$\\approx\$", "\u2248", s)
    s = re.sub(r"\$\\times\$", "\u00d7", s)
    s = re.sub(r"\\,", " ", s)
    s = re.sub(r"\\ ", " ", s)
    s = re.sub(r"\\%", "%", s)
    s = re.sub(r"\\&", "&", s)
    s = re.sub(r"\$([^$]*)\$", r"\1", s)
    s = re.sub(r"\\[a-zA-Z]+\*?(\[[^\]]*\])?(\{[^}]*\})?", "", s)  # drop other cmds
    s = s.replace("\\","")
    s = s.replace("{","").replace("}","")
    s = re.sub(r"[ \t]+"," ", s)
    s = re.sub(r"(?m)^\s*%\s*$","", s)
    s = re.sub(r"(?m)^%\s*","", s)
    s = re.sub(r"\n{3,}","\n\n", s)
    return s.strip()

def parse_blocks(tex):
    """Return ordered list of ('code'|'sh'|'note'|'md', text)."""
    blocks = []
    # tokenize by environments we care about, keeping prose in between
    pat = re.compile(
        r"\\begin\{(pycode|shcode|notebox|tipbox)\}(\[[^\]]*\])?(.*?)\\end\{\1\}",
        re.S)
    pos = 0
    for m in pat.finditer(tex):
        prose = tex[pos:m.start()]
        prose_clean = latex_to_text(prose)
        if prose_clean:
            blocks.append(("md", prose_clean))
        env = m.group(1); body = m.group(3).strip("\n")
        if env == "pycode":
            blocks.append(("code", body))
        elif env == "shcode":
            blocks.append(("sh", body))
        else:  # notebox/tipbox -> note md
            title = "Note" if env=="notebox" else "Tip"
            opt = m.group(2)
            if opt:
                t = opt.strip("[]")
                t = t.replace("\\ "," ").replace("\\","").strip()
                if t: title = t
            blocks.append(("note", f"> **{title}.** " + latex_to_text(body)))
        pos = m.end()
    tail = latex_to_text(tex[pos:])
    if tail:
        blocks.append(("md", tail))
    return blocks

def md_cell(t): return {"cell_type":"markdown","metadata":{},"source":t}
def code_cell(t): return {"cell_type":"code","metadata":{},
                          "execution_count":None,"outputs":[],"source":t}

def clean_code(c):
    # the listings literate replaced -> visually; source already has real ->
    return c

def build(stem):
    tex = open(f"/home/claude/slm_book/chapters/{stem}.tex").read()
    # remove the \chapter{..} and \chapterlede{..} for body parsing; capture lede
    n = NUM[stem]; title = CH_TITLES[stem]
    lede = ""
    m = re.search(r"\\chapterlede\{(.*?)\}\s*\n\n", tex, re.S)
    if m: lede = latex_to_text(m.group(1))
    # drop preamble up to end of chapterlede
    body = tex.split("}\n\n",1)[-1] if "\\chapterlede" in tex else tex
    body = re.sub(r"^.*?\\chapterlede\{.*?\}", "", tex, count=1, flags=re.S)

    cells = []
    header = (f"# Chapter {n}: {title}\n\n"
              f"*Small Language Models in Practice \u2014 Haji Gul*\n\n"
              + (f"> {lede}\n\n" if lede else "")
              + "---\n\n*Lecture notes mirroring the book. Run the setup cell, "
              "then work top-to-bottom. Swap model ids freely.*")
    cells.append(md_cell(header))
    cells.append(md_cell("## Setup\nUncomment what this chapter needs."))
    cells.append(code_cell(
        "# %pip install -q transformers datasets accelerate torch\n"
        "# Chapter-specific installs appear in shell cells below."))

    for kind, text in parse_blocks(body):
        if kind == "code":
            cells.append(code_cell(clean_code(text)))
        elif kind == "sh":
            # shell -> bash cell (commented runnable note)
            cells.append(code_cell("%%bash\n" + text))
        else:  # md or note
            if text.strip():
                cells.append(md_cell(text))

    nb = {"cells":cells,
          "metadata":{"kernelspec":{"display_name":"Python 3","language":"python","name":"python3"},
                      "language_info":{"name":"python","version":"3.11"}},
          "nbformat":4,"nbformat_minor":5}
    fn = f"{OUT}/Chapter_{n:02d}_{title.split(':')[0].replace(' ','_').replace('-','')}.ipynb"
    json.dump(nb, open(fn,"w"), indent=1)
    return fn, sum(1 for c in cells if c["cell_type"]=="code")

for stem in ORDER:
    fn,cc = build(stem)
    print(os.path.basename(fn), "code cells:", cc)
